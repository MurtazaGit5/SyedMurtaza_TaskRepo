

public class EndUI : FlowScreenUI
{

    public void InitUI()
    {
    }

    public override void UpdateUI()
    {
    }

    public override void DestroyUI()
    {
    }
}
