public interface IPlayerLogic
{
    int RunAIBet(ref PlayerData playerData, Pot pot);
}
