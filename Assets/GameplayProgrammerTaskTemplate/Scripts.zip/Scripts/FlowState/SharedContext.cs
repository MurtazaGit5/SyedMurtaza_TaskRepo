public abstract class SharedContext 
{
}

