
public enum PokerPhase 
{
    DealHands,
    Blinds, 
    Preflop,
    Flop,
    Turn,
    River,
    Reveal,
}
