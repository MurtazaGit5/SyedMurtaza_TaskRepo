﻿/// <summary>
/// All the Suits a card can have
/// </summary>
public enum Suit
{
	Spades,
	Hearts,
	Diamonds,
	Clubs
}